package PNProject;

import java.math.BigInteger;
import java.util.stream.IntStream;

public class ParallelProcessingStep4 {
	public static boolean PollardAlgorithm(BigInteger Ma, BigInteger is, BigInteger step, BigInteger P){
		int[] A=new int[1];
		BigInteger[] T=new BigInteger[1];
		A[0]=1;
		boolean COND=true;
		int stepInt=step.intValue();
		
		IntStream.range(1,stepInt).parallel().forEach(jj -> {
			BigInteger ii=BigInteger.valueOf(jj);
			BigInteger R1=ii.multiply(P);
			R1=R1.add(BigInteger.ONE);
			BigInteger R2=Ma.mod(R1);
			if(R2.equals(BigInteger.ONE)) {
				T[0]=R2;
				A[0]=0;
			}
			R1=null; R2=null;ii=null;
	});
		if(A[0]==0) {
			COND=false;
			
		}
		if(A[0]==0) {System.out.println(" it has a factor with value: "+T[0]);}
		return COND;
	}

}
