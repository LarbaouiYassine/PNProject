package PNProject;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.stream.IntStream;

public class ParallelProcessingStep2 {
	public static boolean parallelPrimeVerify(BigInteger Ma, int is, int step, ArrayList PNDatabase){
		int[] A=new int[1];
		BigInteger[] T=new BigInteger[1];
		A[0]=1;
		boolean COND=true;
		int stepInt=step;
		
		IntStream.range(1,stepInt).parallel().forEach(jj -> {
			if(PNDatabase.size()>jj) {
			BigInteger R1=BigInteger.valueOf((int) PNDatabase.get(jj));
			BigInteger R2=Ma.mod(R1);
			if(R2.equals(BigInteger.ZERO)) {
				T[0]=R1;
				A[0]=0;
			}
			R1=null; R2=null;
			}
	     });
		if(A[0]==0 && !Ma.equals(T[0])) {
			COND=false;
			
		}
		if(COND==false) {System.out.println(" it has a factor with value: "+T[0]);}
		return COND;
	}


}
