package PNProject;

import java.math.BigInteger;

public class PrimeVerifyStep5 {
	public static boolean LucasLehmerAlgorithm(BigInteger Ma, int p){
		System.out.println("*********** Processes of Step 5 are started:  ");
		BigInteger S=new BigInteger("4");
		BigInteger test;
		BigInteger T;
		BigInteger R=new BigInteger("2");
		BigInteger Rt=new BigInteger("4");
		BigInteger s=BigInteger.valueOf(p);
		int ii;
		System.out.println(" p is:  "+p);
		for(ii=1; ii<p-1;ii++) {
			S=S.pow(2).subtract(R).mod(Ma);
			if(S.equals(BigInteger.ZERO)) {	
			}
			if(S.equals(BigInteger.ONE)) {	
			}
		}
		boolean COND=true;
		if(!S.equals(BigInteger.ZERO)) {
			COND=false;
		}
		System.out.println(" Step 5: is it a prime:  "+COND);
		return COND;
		
	}

}
