**************************************
**************************************
**************************************
This is a customizable resource of codes developed by Yassine Larbaoui for individual interests of finding or verifying Mersenne Prime numbers.
These codes are independent from being slaved by Super Infinity Calculator for collaborative processing through networks, which enables individuals to use these codes freely.

