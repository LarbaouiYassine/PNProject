package PNProject;

import java.math.BigInteger;

import javax.swing.JOptionPane;

public class PrimeVerifyA {
	
	
	public static boolean PrimeVerify(BigInteger Ma, int p){
		boolean COND1=true, COND2=false, COND3;
		BigInteger is=BigInteger.ONE;
		int limit=Ma.bitLength(), ii = 0;
		BigInteger R=new BigInteger("2");
		BigInteger RR=new BigInteger("4");
		while(COND1!=false && ii<limit && COND2 ==false) {
			 R=R.pow(2);
			 R=R.mod(Ma);
			 if(R.equals(new BigInteger("4")) && ii!=0) {
					System.out.println(" ***** ii is: "+ii);
					COND2=true;
					BigInteger M=BigInteger.valueOf(ii);
					COND3=PrimeLib.PrimeVerify2(M);
					if(COND3==true || ii==p-1 ) {
						COND1=true;
						
					}else {
						COND1=false;
					}
					
				 }
			 ii+=1;
			
		}
		
		System.out.println(" ***** is it prime: "+COND1);
		
		return COND1;
	}

}
