package PNProject;

import java.math.BigInteger;

public class PrimeVerifyStep3 {
	public static boolean PrimeVerify(BigInteger Ma){
		BigInteger R1, R2;
		int count=0;
		int limit=Ma.bitLength();
		System.out.println("*********** Processes of Step 3 are started:  ");
		double e=(limit)/2+1;
		int ee=(int)Math.floor(e);
		int Dlimit;
		if(e==ee) {
			Dlimit=ee;
		}else {
			Dlimit=ee+1;
		}
		BigInteger essence=new BigInteger("2");
		BigInteger MaxD=essence.pow(Dlimit);
		BigInteger MaxD2=essence.pow(Dlimit-1);
		BigInteger ii=new BigInteger("3");
		int comparei=ii.compareTo(MaxD);
		boolean COND=true;
		BigInteger step=new BigInteger("10000000");
		BigInteger ILimit=MaxD2.divide(step);
		BigInteger is=ILimit;
		BigInteger seuil=BigInteger.ZERO;
		while(COND!=false && is.compareTo(seuil)>-1) {
			
			COND=ParallelProcessingStep3.PrimeVerify(Ma, is, step);
			is=is.subtract(BigInteger.ONE);
		}
		System.out.println(" Step 3: is it a prime:  "+COND);
		
		return COND;
		
	}

}
