package PNProject;

import java.math.BigInteger;

public class PrimeVerifyB {
	public static boolean PrimeVerify(BigInteger Ma, int p){
		boolean COND1=false, COND2=false;
		BigInteger R=new BigInteger("2");
		BigInteger RR=new BigInteger("1"), T;
		BigInteger is=new BigInteger("0");
		BigInteger P=BigInteger.valueOf(p);
		BigInteger seuil=Ma.subtract(BigInteger.ONE);
	
		while(COND1!=true && COND2==false && 0>is.compareTo(seuil)) {
			RR=RR.multiply(R);
			is=is.add(BigInteger.ONE);
			T=RR.mod(Ma);
			if(T.equals(BigInteger.ONE)) {
				COND2=true;
				if(seuil.mod(is).equals(BigInteger.ZERO)) {
					COND1=true;
				}else {
					COND1=false;
				}
			}
			

		}
		System.out.println(" ***** is it prime: "+COND1);
		
		
		
		
		
		
		
		
		
		
		
		return COND1;
		
		
	}

}
