package PNProject;

import java.math.BigInteger;

public class PrimeLib {
	
	public static boolean PrimeVerify2(BigInteger Ma){
		BigInteger R1, R2;
		int count=0;
		int limit=Ma.bitLength();
		double e=(limit)/2+1;
		int ee=(int)Math.floor(e);
		int Dlimit;
		if(e==ee) {
			Dlimit=ee;
		}else {
			Dlimit=ee+1;
		}
		BigInteger essence=new BigInteger("2");
		BigInteger MaxD=essence.pow(Dlimit);
		BigInteger ii=new BigInteger("3");
		int comparei=ii.compareTo(MaxD);
		boolean COND=true;
		while(COND==true && 0>ii.compareTo(MaxD)) {
			R1=ii;
			R2=Ma.mod(R1);
			if(R2.equals(BigInteger.ZERO)) {
				COND=false;
				System.out.println("***********divider is:  "+ R1);
			}
			ii=ii.add(new BigInteger("2"));
			
		}
		
		return COND;
		
	}

}
