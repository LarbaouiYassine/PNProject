package PNProject;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.stream.IntStream;

public class PrimeVerifyStep2 {
	public static boolean PrimeVerify(BigInteger Ma, ArrayList PNDatabase){
		System.out.println("***********Processes of Step 1 are started:  ");
		int MaxD2=PNDatabase.size();
		boolean COND=true;
		int step=10000000;
		int ILimit=Math.floorDiv(MaxD2, step);
		int is=0;
		while(COND!=false && ILimit>=is) {
			COND=ParallelProcessingStep2.parallelPrimeVerify(Ma, is, step, PNDatabase);
			is+=1;
		}
		System.out.println(" Step 1: is it a prime:  "+COND);
		return COND;
		
	}
		

}
