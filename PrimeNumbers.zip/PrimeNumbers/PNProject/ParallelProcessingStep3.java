package PNProject;

import java.math.BigInteger;
import java.util.stream.IntStream;

public class ParallelProcessingStep3 {
	public static boolean PrimeVerify(BigInteger Ma, BigInteger is, BigInteger step){
		int[] A=new int[1];
		BigInteger[] T=new BigInteger[1];
		A[0]=1;
		boolean COND=true;
		BigInteger StartThis=is.multiply(step);
		int stepInt=step.intValue();
		
		IntStream.range(1,stepInt).parallel().forEach(jj -> {
			BigInteger ii=BigInteger.valueOf(jj);
			BigInteger R1=ii.multiply(new BigInteger("2"));
			R1=R1.add(BigInteger.ONE);
			R1=R1.add(StartThis);
			BigInteger R2=Ma.gcd(R1);
			if(!R2.equals(BigInteger.ONE)) {
				T[0]=R2;
				A[0]=0;
			}
			R1=null; R2=null;ii=null;
	});
		if(A[0]==0) {
			COND=false;
			
		}
		if(A[0]==0) {System.out.println(" it is related to: "+T[0]);}
		return COND;
	}
	

}
