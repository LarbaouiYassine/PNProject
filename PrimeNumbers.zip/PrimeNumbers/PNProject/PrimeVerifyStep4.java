package PNProject;

import java.math.BigInteger;

public class PrimeVerifyStep4 {
	
	public static boolean PrimeVerify(BigInteger Ma, int p){
		System.out.println("*********** Processes of Step 4 are started:  ");
		BigInteger R1, R2;
		BigInteger P=BigInteger.valueOf(2*p);
		int count=0;
		BigInteger limit=Ma.divide(P);
		BigInteger step=new BigInteger("10000000");
		BigInteger ILimit=limit.divide(step);
		BigInteger is=ILimit;
		boolean COND=true;
		BigInteger seuil=BigInteger.ONE;
		while(COND!=false && is.compareTo(seuil)>-1) {
			COND=ParallelProcessingStep3.PrimeVerify(Ma, is, step);
			is=is.subtract(BigInteger.ONE);
		}
		System.out.println(" Step 4: is it a prime:  "+COND);
		return COND;
		
	}

}
