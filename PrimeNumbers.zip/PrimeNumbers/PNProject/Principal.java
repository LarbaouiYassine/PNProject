package PNProject;

import java.math.BigInteger;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class Principal {

	public static void main(String[] args) {
		 
		try {
			 boolean STEP2=false, STEP3=false, STEP4=false, STEP5=false, STEP6=true;
			 boolean COND=true;
			 Instant starta, enda;
			 long timeElapsed;
             BigInteger A=new BigInteger("2");
             int P=81;
             BigInteger Ma=A.pow(P);
             Ma=Ma.subtract(BigInteger.ONE);
             ArrayList PNDatabase=LoadPNDatabase.LoadPrimesList();
             System.out.println(" array list:  "+PNDatabase.size());
             if(STEP2==true) {
             starta = Instant.now();
			 COND=PrimeVerifyStep2.PrimeVerify(Ma, PNDatabase);
			 enda = Instant.now();
			 timeElapsed = Duration.between(starta, enda).toHours();
			 JOptionPane.showMessageDialog(null, "  Cosumed Time for Step2:     "+timeElapsed); 
			 JOptionPane.showMessageDialog(null, "*******Step2: is it a prime:     "+COND+"******");
             }
			 boolean COND3=true;
			 if(COND==true && STEP3==true) {
				 
				 starta = Instant.now();
				 COND3=PrimeVerifyStep3.PrimeVerify(Ma);
				 enda = Instant.now();
				 timeElapsed = Duration.between(starta, enda).toHours();
				 JOptionPane.showMessageDialog(null, "  Cosumed Time for Step3(Step4):     "+timeElapsed);
				 JOptionPane.showMessageDialog(null, "*******Step3(Step(4): is it a prime:     "+COND3+"******");
			 }
			 boolean COND4=true;
            if(STEP4==true) {
				 starta = Instant.now();
				 COND4=PrimeVerifyStep3.PrimeVerify(Ma);
				 enda = Instant.now();
				 timeElapsed = Duration.between(starta, enda).toHours();
				 JOptionPane.showMessageDialog(null, "  Cosumed Time for Step4:     "+timeElapsed);
				 JOptionPane.showMessageDialog(null, "*******Step4: is it a prime:     "+COND4+"******");
				
			 }
            boolean COND5=true;
			 if(STEP5==true &&(COND3==true || COND4==true)) {
				 
				 starta = Instant.now();
				 COND5=PrimeVerifyStep5.LucasLehmerAlgorithm(Ma, P);
				 enda = Instant.now();
				 timeElapsed = Duration.between(starta, enda).toHours();
				 JOptionPane.showMessageDialog(null, "  Cosumed Time for Step3(Step4):     "+timeElapsed);
				 JOptionPane.showMessageDialog(null, "*******Step3(Step(4): is it a prime:     "+COND5+"******");
				 
			 }
			 
			 boolean COND6=true;
			 if(STEP6==true) {
				 
				 starta = Instant.now();
				 COND6=PrimeVerifyA.PrimeVerify(Ma, P);
				 enda = Instant.now();
				 timeElapsed = Duration.between(starta, enda).toHours();
				 JOptionPane.showMessageDialog(null, "  Cosumed Time for Step6:     "+timeElapsed);
				 JOptionPane.showMessageDialog(null, "*******Step6: is it a prime:     "+COND6+"******");
				 
			 }
			 JOptionPane.showMessageDialog(null, "*******PROCESSING IS ENDED******");
			
			
			UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
		} catch(Exception ee) {
			System.out.println(ee);
			
		}
		
	}

}
