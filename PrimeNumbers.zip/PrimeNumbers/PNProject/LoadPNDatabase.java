package PNProject;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class LoadPNDatabase {
	public static ArrayList LoadPrimesList(){
		int i, r, lines, j;
		lines=0;
        ArrayList Registertrans1=new ArrayList();
		try (BufferedReader br = new BufferedReader(new FileReader("D:\\SavedResultsSC\\primes\\database\\PN-Database.txt"))) {
		    String line;
		    Registertrans1.clear();
		    while ((line = br.readLine()) != null) {
		        String[] lineItems = line.split(";");
		        for(i=0;i<lineItems.length;i+=1) {Registertrans1.add(Integer.parseInt(lineItems[i]));}
		    }
		    br.close();
			}
			catch(Exception e1){
		}
		return Registertrans1;
		
		
		
	}
	

}
